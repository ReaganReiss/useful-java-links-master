Contribution Guidelines

Please ensure your pull request follows the following guidelines:

1. Please make an individual pull request for each suggestion.
2. Use the following format for libraries: [LIBRARY](LINK) - DESCRIPTION.
3. New categories, or any improvements to the existing categorization are welcome.

Thank you for your suggestions!
