My articles (in English): 

1. [Alternative java collections overview](https://github.com/Vedenin/useful-java-links/tree/master/helloworlds/1.6-usefull-libraries/collections) 
1. [All Java libraries](https://github.com/Vedenin/useful-java-links)
1. [Json](https://github.com/Vedenin/useful-java-links/tree/master/helloworlds/3.8-json)
1. [jdk_stream_api](https://github.com/Vedenin/useful-java-links/tree/master/helloworlds/1.6-usefull-libraries/functional_programming/jdk_stream_api)
1. [Dependency Injection and AOP: Dagger,Guava,Spring](https://github.com/Vedenin/useful-java-links/tree/master/helloworlds)
1. [Bean Mapping and Validation:  Dozer, MapStruct, ModelMapper, Orika, Selma](https://github.com/Vedenin/useful-java-links/tree/master/helloworlds)
1. [Other](https://github.com/Vedenin/useful-java-links/tree/master/helloworlds)

My articles (in Russian): [this](https://habrahabr.ru/users/vedenin1980/topics/)
